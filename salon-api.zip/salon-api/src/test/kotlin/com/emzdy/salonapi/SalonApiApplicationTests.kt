package com.emzdy.salonapi

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SalonApiApplicationTests {

	@Test
	fun contextLoads() {
	}

}
